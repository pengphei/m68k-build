#! /bin/bash

ROOT_DIR=`pwd`

#clean up 
file_name="oldversion_cleanup.pl";
perl windriver/$file_name;

#begin install 
if [ ! -r /usr/local/PEMicrocomputerSystems ] ; then 
  mkdir /usr/local/PEMicrocomputerSystems
  mkdir /usr/local/PEMicrocomputerSystems/windriver
  chown -R  root /usr/local/PEMicrocomputerSystems
fi

cp -rf "$ROOT_DIR"/windriver /usr/local/PEMicrocomputerSystems
chmod -R 777 /usr/local/PEMicrocomputerSystems/windriver/lib/

cd /usr/local/PEMicrocomputerSystems/windriver/redist
ROOT_DIR='/usr/local/PEMicrocomputerSystems'
./configure  
make clean  
make       
make install 
#install finished
#setup 
module_base_name=windrvr6
bootlocal='/etc/rc.d/boot.local'
rclocal='/etc/rc.d/rc.local'
if [ -w $bootlocal ] ; then
if [[ $(grep -c 'wdreg windrvr6 auto' /etc/rc.d/boot.local) = 0 ]];then
echo 'wdreg windrvr6 auto' >> /etc/rc.d/boot.local
echo 'chmod 666 /dev/windrvr6' >> /etc/rc.d/boot.local
fi 
fi
if [ -w $rclocal ] ; then 
if [[ $(grep -c 'wdreg windrvr6 auto' /etc/rc.d/rc.local) = 0 ]];then
echo 'wdreg windrvr6 auto' >> /etc/rc.d/rc.local
echo 'chmod 666 /dev/windrvr6' >> /etc/rc.d/rc.local
fi 
fi
module_base_name=windrvr6
VER=`uname -r`
VER_MAJOR=`echo $VER | cut -f 1 -d "."`
VER_MINOR=`echo $VER | cut -f 2 -d "."`
VER_SUBMINOR=`echo $VER | cut -f 3 -d "." | cut -f 1 -d "-"`
use_udev="no"
if test ${VER:0:3} = "2.6" ; then
	if test $VER_SUBMINOR -lt 13 ; then
		UDEV=`ps -ef | grep -w udevd | grep -vc grep`
		if test $UDEV != 0; then
			use_udev="yes"
		fi
	fi
fi
if [ $use_udev == "yes" ] ; then 
if [ -w /etc/udev/permissions.d/50-udev.permissions ] ; then 
if [ $(grep -c 'windrvr6:root:root:0666' /etc/udev/permissions.d/50-udev.permissions) = 0 ] ; then
echo windrvr6:root:root:0666 >> /etc/udev/permissions.d/50-udev.permissions
fi 
fi
fi
#now copy files
if [ ! -r /usr/lib/bplrtl.so.6.9.0 ] ; then  
cp ../lib/bplrtl.so.6.9.0 /usr/lib/bplrtl.so.6.9.0
fi 
if [ ! -r /usr/lib/bplvisualclx.so.6.9.0 ] ; then  
cp ../lib/bplvisualclx.so.6.9.0 /usr/lib/bplvisualclx.so.6.9.0
fi 
if [ ! -r /usr/lib/libborunwind.so.6.0  ] ; then  
cp ../lib/libborunwind.so.6.0 /usr/lib/libborunwind.so.6.0
fi 
if [ ! -x /sbin/wdreg ] ; then 
cp ../redist/wdreg /sbin/wdreg 
fi
#check for success
echo "Waiting 15 seconds for windriver's kernel module to load..." 
sleep 15s

file='/dev/windrvr6'
ls "$file" >/dev/null 2>&1 
if [ $? -eq 0 ] 
 then 
      echo "********* ********** ********** ******** *********" 	
      echo "********* ********** ********** ******** *********" 	
      echo "********* ********** ********** ******** *********" 		
      echo "********* P&E Install has been a success *********" 
      echo "********* ********** ********** ******** *********" 	
      echo "********* ********** ********** ******** *********"
      echo "********* ********** ********** ******** *********"
 chmod 666 $file
 else 
      echo "********* ********** ********** ******** *********" 	
      echo "********* ********** ********** ******** *********" 	
      echo "********* ********** ********** ******** *********" 		
      echo "********* P&E Install has failed******** *********" 
      echo "********* ********** ********** ******** *********" 	
      echo "********* ********** ********** ******** *********"
      echo "********* ********** ********** ******** *********" 
fi
