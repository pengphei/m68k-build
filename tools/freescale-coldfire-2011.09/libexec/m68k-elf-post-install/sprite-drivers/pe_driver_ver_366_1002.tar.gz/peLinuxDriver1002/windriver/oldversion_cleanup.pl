#!/usr/lib/perl -w 

open FILE, '/etc/modprobe.conf' || die("Cannot open /etc/modprobe.conf");   

open(FILE, "/etc/modprobe.conf"); 
my @data; 
my $c=0; 
for (<FILE>){ 
 if ((/windriver/)||(/windrvr6/)){
 next;  
 }else{$data[$c]=$_;}
 ++$c;
}
close(FILE); 

open(DAT, ">/etc/modprobe.conf") || die("Cannot open /etc/modprobe.conf"); 
print DAT @data; 
close(DAT);

print "cleaned old version install", "\n"; 
